#!/bin/bash

./userapp 800 8&
./userapp 1000 5&
./userapp 500 10&

